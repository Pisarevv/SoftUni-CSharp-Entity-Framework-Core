﻿namespace P01_StudentSystem.Common;

public class DbConfig
{
    public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=StudentSystem;Integrated Security=true;TrustServerCertificate = true";
}
