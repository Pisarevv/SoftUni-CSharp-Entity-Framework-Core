﻿namespace P02_FootballBetting.Common;


public class DbConfig
{
    public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=Bet393;Integrated Security=true;TrustServerCertificate = true";
}
