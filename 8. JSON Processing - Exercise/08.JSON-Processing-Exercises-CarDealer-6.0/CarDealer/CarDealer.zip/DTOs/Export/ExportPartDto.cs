﻿namespace CarDealer.DTOs.Export;

public class ExportPartDto
{
    public string Name { get; set; } = null!;

    public string Price { get; set; } = null!;
}
