﻿namespace ProductShop.DTOs.Export;

public class UsersCountDto
{
    public int UsersCount { get; set; }

    public UserDto[] Users { get; set; }
}
