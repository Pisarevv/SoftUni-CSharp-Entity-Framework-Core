﻿namespace ProductShop.DTOs.Export;

public class ProductDto
{
    public string Name { get; set; }

    public decimal Price { get; set; }
}
