﻿namespace Artillery.DataProcessor.ImportDto;

public class ImportCountryIdDto
{
    public int Id { get; set; }
}
